## Features

Features for various profiles which add code features; useful for making your own profiles (e.g. inheriting from *camel-jms* to add the necessary code features)

