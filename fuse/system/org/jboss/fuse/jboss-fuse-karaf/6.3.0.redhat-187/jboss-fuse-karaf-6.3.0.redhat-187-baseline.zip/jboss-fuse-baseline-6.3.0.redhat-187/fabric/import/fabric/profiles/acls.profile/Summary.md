This profile is used to group all the ACLs configuration.
It's expected to be used as a parent profile.
