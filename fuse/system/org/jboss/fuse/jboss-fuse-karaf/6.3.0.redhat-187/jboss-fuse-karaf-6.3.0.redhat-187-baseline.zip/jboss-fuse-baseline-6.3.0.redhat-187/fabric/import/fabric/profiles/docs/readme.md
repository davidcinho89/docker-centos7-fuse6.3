## Welcome to Fabric8

<div alt="Fabric8 Logo" style="width: 500px; text-align: center">
  <img src="/app/fabric/doc/img/fabric8_logo.svg">
</div>

### Getting Started

Try running some of the <a class="btn btn-primary" href="/fabric/profiles/ReadMe.md" title="View all the available profiles you can create">Available Profiles</a>

### Documentation

<ul>
  <li>
    <a class="btn" href="/fabric/profiles/docs/fabric/index.md">Documentation</a>
  </li>
</ul>


### Support

<ul>
  <li>
    <a class="btn" href="http://fabric8.io/community/">Community</a>
  </li>
</ul>
