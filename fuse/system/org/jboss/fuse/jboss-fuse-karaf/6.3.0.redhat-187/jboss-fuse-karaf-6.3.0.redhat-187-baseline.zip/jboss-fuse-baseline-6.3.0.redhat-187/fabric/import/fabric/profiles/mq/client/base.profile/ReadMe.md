A base profile to define the code for a JMS client; inherited by all the actual concrete profiles. Typically we have a profile per group of brokers.
