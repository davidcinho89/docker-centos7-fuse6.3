A profile which provides an ActiveMQConnectionFactory (JMS client) for connecting via JMS or Camel to an A-MQ broker running in default group
