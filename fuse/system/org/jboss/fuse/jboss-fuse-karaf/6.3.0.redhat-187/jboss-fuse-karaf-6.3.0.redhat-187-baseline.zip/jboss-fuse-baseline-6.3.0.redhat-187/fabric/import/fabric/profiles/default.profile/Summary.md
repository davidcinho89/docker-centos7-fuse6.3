This is a base profile which is useable to extend by custom profiles
