## JBoss

This folder contains profiles for various JBoss products.

* [fuse](/fabric/profiles/jboss/fuse) the JBoss Fuse product
