a profile for running A-MQ broker in a replicated configuration
