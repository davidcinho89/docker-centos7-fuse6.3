This is the Apache Karaf profile
