Support tools for Karaf and Fabric

a `support-base` profile is defined in Fabric.  
To enable it:
```
container-add-profile root support-base
```
    
 