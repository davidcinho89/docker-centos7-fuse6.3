This is the JBoss Fuse full profile
